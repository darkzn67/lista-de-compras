import React, { useState } from 'react';
import { View, TextInput, TouchableOpacity, Text } from 'react-native';
import { styles } from './styles'; // mantenha o arquivo de estilos que já existia

interface FormProps {
  onAdicionar: (nome: string) => void;
}

export default function Form({ onAdicionar }: FormProps) {
  const [texto, setTexto] = useState('');

  function handleAdicionar() {
    if (!texto.trim()) return;
    onAdicionar(texto);
    setTexto('');
  }

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="O que você precisa comprar?"
        value={texto}
        onChangeText={setTexto}
      />
      <TouchableOpacity style={styles.botao} onPress={handleAdicionar}>
        <Text style={styles.botaoTexto}>Adicionar</Text>
      </TouchableOpacity>
    </View>
  );
}
