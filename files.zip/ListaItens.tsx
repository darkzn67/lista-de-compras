import React from 'react';
import { View, FlatList, TouchableOpacity, Text } from 'react-native';
import ProdutoListaItem from '../ProdutoListaItem/ProdutoListaItem';
import { ProdutoItem } from '../../interfaces/ProdutoItem';
import { styles } from './styles'; // mantenha o arquivo de estilos que já existia

interface ListaItensProps {
  produtos: ProdutoItem[];
  abaAtiva: 'presentes' | 'comprados';
  onMudarAba: (aba: 'presentes' | 'comprados') => void;
  onAlternarComprado: (id: string) => void;
  onRemover: (id: string) => void;
  onLimpar: () => void;
}

export default function ListaItens({
  produtos,
  abaAtiva,
  onMudarAba,
  onAlternarComprado,
  onRemover,
  onLimpar,
}: ListaItensProps) {
  // Filtra os dados de acordo com a aba selecionada, sem alterar o array original
  const produtosFiltrados = produtos.filter((produto) =>
    abaAtiva === 'presentes' ? !produto.comprado : produto.comprado
  );

  return (
    <View style={styles.container}>
      {/* Mantenha aqui o seu componente/estilo de abas já pronto no layout,
          só ligando o onPress de cada aba ao onMudarAba */}
      <View style={styles.abas}>
        <TouchableOpacity onPress={() => onMudarAba('presentes')}>
          <Text>Presentes</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => onMudarAba('comprados')}>
          <Text>Comprados</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={produtosFiltrados}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ProdutoListaItem
            produto={item}
            onAlternarComprado={onAlternarComprado}
            onRemover={onRemover}
          />
        )}
      />

      <TouchableOpacity style={styles.botaoLimpar} onPress={onLimpar}>
        <Text>Limpar</Text>
      </TouchableOpacity>
    </View>
  );
}
