import React from 'react';
import { TouchableOpacity, Text } from 'react-native';
import { ProdutoItem } from '../../interfaces/ProdutoItem';
import { styles } from './styles'; // mantenha o arquivo de estilos que já existia
                                    // (é onde o check + texto riscado do item comprado já estão)

interface ProdutoListaItemProps {
  produto: ProdutoItem;
  onAlternarComprado: (id: string) => void;
  onRemover: (id: string) => void;
}

export default function ProdutoListaItem({
  produto,
  onAlternarComprado,
  onRemover,
}: ProdutoListaItemProps) {
  return (
    <TouchableOpacity style={styles.item} onPress={() => onAlternarComprado(produto.id)}>
      <Text style={produto.comprado ? styles.textoComprado : styles.texto}>
        {produto.nome}
      </Text>

      <TouchableOpacity onPress={() => onRemover(produto.id)}>
        <Text>🗑️</Text>
      </TouchableOpacity>
    </TouchableOpacity>
  );
}
