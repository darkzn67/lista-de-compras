import React, { useState, useEffect } from 'react';
import { View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// TODO(aluno): ajuste estes imports para os caminhos reais do seu projeto
import Header from './components/Header/Header';
import Form from './components/Form/Form';
import ListaItens from './components/ListaItens/ListaItens';
import { ProdutoItem } from './interfaces/ProdutoItem';
import { styles } from './styles'; // mantenha o arquivo de estilos que já existia no seu App.tsx

const STORAGE_KEY = '@minha_lista_compras';

// Mock inicial usado só na primeiríssima execução (sem nada salvo ainda).
// Troque por [] se preferir que o app comece vazio.
const produtosMock: ProdutoItem[] = [];

export default function App() {
  const [produtos, setProdutos] = useState<ProdutoItem[]>([]);
  const [abaAtiva, setAbaAtiva] = useState<'presentes' | 'comprados'>('presentes');
  const [carregado, setCarregado] = useState(false);

  // Carrega os dados salvos assim que o app abre
  useEffect(() => {
    async function carregarDados() {
      try {
        const json = await AsyncStorage.getItem(STORAGE_KEY);
        setProdutos(json ? JSON.parse(json) : produtosMock);
      } catch (erro) {
        console.error('Erro ao carregar produtos do AsyncStorage:', erro);
        setProdutos(produtosMock);
      } finally {
        setCarregado(true);
      }
    }
    carregarDados();
  }, []);

  // Salva sempre que a lista mudar (evita sobrescrever antes do carregamento inicial)
  useEffect(() => {
    if (!carregado) return;
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(produtos)).catch((erro) =>
      console.error('Erro ao salvar produtos no AsyncStorage:', erro)
    );
  }, [produtos, carregado]);

  function adicionarProduto(nome: string) {
    const nomeLimpo = nome.trim();
    if (!nomeLimpo) return;

    const novoProduto: ProdutoItem = {
      id: Date.now().toString(),
      nome: nomeLimpo,
      comprado: false,
    };

    setProdutos((atuais) => [...atuais, novoProduto]);
  }

  function alternarComprado(id: string) {
    setProdutos((atuais) =>
      atuais.map((produto) =>
        produto.id === id ? { ...produto, comprado: !produto.comprado } : produto
      )
    );
  }

  function removerProduto(id: string) {
    setProdutos((atuais) => atuais.filter((produto) => produto.id !== id));
  }

  function limparItens(comprados: boolean) {
    setProdutos((atuais) => atuais.filter((produto) => produto.comprado !== comprados));
  }

  return (
    <View style={styles.container}>
      <Header />

      <Form onAdicionar={adicionarProduto} />

      <ListaItens
        produtos={produtos}
        abaAtiva={abaAtiva}
        onMudarAba={setAbaAtiva}
        onAlternarComprado={alternarComprado}
        onRemover={removerProduto}
        onLimpar={() => limparItens(abaAtiva === 'comprados')}
      />
    </View>
  );
}
